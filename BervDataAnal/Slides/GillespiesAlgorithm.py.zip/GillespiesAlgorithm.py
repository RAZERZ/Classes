"""
Stochastic Simulation Algorithm (or Gillespies algorithm)

By: Davoud Mirzaei, Uppsala University, April 2023

"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp


############## Stochastic Solution with SSA #########################

######  Required subroutines

## Generate N random numbers from exponential distribution
def RandExp(lam,N):
    # lam: distribution parameter, N: number of requested samples
    U =  np.random.rand(N)  # generate N uniform numbers in [0,1)
    X = -1/lam*np.log(1-U)  # use inverse transform to generate X
    return X

## Generate N random numbers from discrete distribution with  
#                a sorted state vector x and probability vector p   
def RandDisct(x,p,N):
    # x: sorted states, p: probabilities, N: number of requested samples
    cdf = np.cumsum(p)           # compute the cumulative vector
    U = np.random.rand(N)        # generate N uniform numbers in [0,1)
    idx = np.searchsorted(cdf, U)  # search U values in cdf intervals
    return x[idx]

##  SSA algorithm 
def SSA(Initial, StateChangeMat, FinalTime):
   # Inputs:
   #  Initial: initial conditins of size (StateNo x 1)
   #  StateChangeMat: State-change matrix of size (ReactNo, StateNo)
   #  FinalTime: the maximum time we want the process be run

   # Output:
   #  AllTimes: the list of all selected time levels 
   #  AllStates: the list of all state values at corresponding time levels

    [m,n] = StateChangeMat.shape
    ReactNum = np.array(range(m))
    AllTimes = {}   # define a list for storing all time levels
    AllStates = {}  # define a list for storing all states at all time levels
    AllStates[0] = Initial
    AllTimes[0] = [0]
    k = 0; t = 0; State = Initial
    while True:
        w = PropensityFunc(State, m)     # propensities
        a = np.sum(w)
        tau = RandExp(a,1)               # WHEN the next reaction happens
        t = t + tau                      # update time
        if t > FinalTime:
            break
        which = RandDisct(ReactNum,w/a,1)             # WHICH reaction occurs
        State = State + StateChangeMat[which.item(),] # Uppdate the state
        k += 1
        AllTimes[k] = t
        AllStates[k] = State
    return AllTimes, AllStates

## rates
mu, bet, gam = 1e-4, 0.25, 0.05   # rates

## Propensity functions (for SIR model)
def PropensityFunc(State, ReactNo):
    S,I,R = State 
    N = S + I + R;
    w = np.zeros(ReactNo)
    w[0] = mu * N              # birth (newborns)
    w[1] = bet/N * S * I       # infection
    w[2] = gam * I             # recovery
    w[3] = mu * S              # death of susceptible individuals
    w[4] = mu * I              # death of infected individuals
    w[5] = mu * R              # death of recovered individuals
    return w

#####################################################################
# SSA Simulation of SIR model 

Initial = [198,2,0] # initial number of Susceptible, Infected and Recovered individuals
FinalTime = 120  # final time of simulation

# State-change  matrix
StateChangeMat = np.array([
                    [+1,  0,  0],
                    [-1, +1,  0],
                    [ 0, -1, +1],
                    [-1,  0,  0],
                    [ 0, -1,  0],
                    [ 0,  0, -1]])

# Stochastic Simulation
N = 10   # number of simulations
plt.figure(figsize = (6, 4))
for k in range(N):
    Time, States = SSA(Initial, StateChangeMat, FinalTime) 
    n = len(Time)
    t = [Time[i][0] for i in range(n)]
    S = [States[i][0] for i in range(n)]
    I = [States[i][1] for i in range(n)]
    R = [States[i][2] for i in range(n)]
    plt.plot(t,S,linestyle = '-', color='blue')
    plt.plot(t,I,linestyle = '-', color='red')
    plt.plot(t,R,linestyle = '-', color='green')
plt.xlabel('Time');
plt.ylabel('Individuals');
plt.title('Stochastic solutions using SSA')
plt.legend(['$S$','$I$','$R$'],loc='center right')
plt.show()


####################################################################


############## Deteministic solution #########################

## Right hand side of the ODE (deterministic model)
def ODEfun(t,y):
    yprime = np.zeros(3); 
    S,I,R = y
    N = np.sum(y)
    yprime[0] = mu*N - bet*S*I/N-mu*S
    yprime[1] = bet*S*I/N -(mu+gam)*I
    yprime[2] = gam*I - mu*R
    return yprime

teval = np.linspace(0, FinalTime,500)
sol = solve_ivp(ODEfun, [0,FinalTime], Initial,t_eval = teval)

plt.figure(figsize = (6, 4))
plt.plot(sol.t,sol.y[0],linestyle = 'solid', color='blue', label = '$S$')
plt.plot(sol.t,sol.y[1],linestyle = 'solid', color='red', label = '$I$')
plt.plot(sol.t,sol.y[2],linestyle = 'solid', color='green', label = '$R$')
plt.xlabel('time $t$'); plt.ylabel('Individuals')
plt.title('Deterministic solution using RK45')
plt.legend(loc='center right')
plt.show()


